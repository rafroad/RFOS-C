#ifndef _JTE_RSYNC_H_
#define _JTE_RSYNC_H_

uint64_t rsync64(unsigned char *mem, size_t size);

#endif
